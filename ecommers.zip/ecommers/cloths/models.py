from django.db import models

class Cloths(models.Model):
    color=models.CharField(max_length=40)
    size=models.CharField(max_length=40)
# Create your models here.
