from django.shortcuts import render,get_list_or_404,redirect
from django.http import HttpResponse
from .models import Cloths

def cloths_list(request):
    return HttpResponse("Cloths List Page")

def cloths_list(request):
    cloth=Cloths.objects.all()
    return render(request, 'cloths_list.html', {'cls':cloth})

