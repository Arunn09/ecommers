from django.contrib import admin
from .models import Cloths


@admin.register(Cloths)
class ClothsAdmin(admin.ModelAdmin):
    list_display = ('color', 'size')
# Register your models here.
