from django.contrib import admin
from .models import Groceries


@admin.register(Groceries)
class GroceriesAdmin(admin.ModelAdmin):
    list_display = ('Type', 'Quantity')
# Register your models here.
