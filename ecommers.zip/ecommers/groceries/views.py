from django.shortcuts import render
from django.http import HttpResponse
from .models import Groceries

def groceries_list(request):
    return HttpResponse("gross List Page")


def groceries_list(request):
    grocerie=Groceries.objects.all()
    return render(request, 'gross_list.html', {'gos':grocerie})
