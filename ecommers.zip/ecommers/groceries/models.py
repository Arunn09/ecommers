from django.db import models

class Groceries(models.Model):
    Type= models.CharField(max_length=50)
    Quantity = models.CharField(max_length=255)


# Create your models here.
