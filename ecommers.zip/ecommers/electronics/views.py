from django.shortcuts import render
from django.http import HttpResponse
from .models import Electronics

def electronics_list(request):
    return HttpResponse("elect List Page")


def electronics_list(request):
    electronics = Electronics.objects.all()
    return render(request, 'electro_list.html', {'ele': electronics})