from django.contrib import admin
from .models import Electronics


@admin.register(Electronics)
class ElectronicsAdmin(admin.ModelAdmin):
    list_display = ('name', 'price')
# Register your models here.
